Please follow these steps:

1. Copy and Paste files 'music' and 'upload_music' to htdocs.

2. Import art database in MYSQL.

3. In all PHP files, my computer path to upload  is 'D:/Xampp/htdocs/upload_music/'. 
So, in your PC, change it to your correspond path. This must be done for all the PHP files.

4. Run XAMPP. Run MYSQL and APACHE. Server must be 80.


Note:
A user will be role 'user' by default , please chnange role to 'admin' for 
admin access in MySQL Database i.e 'music.sql'. Manager is hayabusa@gmail.com with password: Pass1234
From logging in with this id, we can add new product , update staus and all. 
Only registered user can comment and do bookings.


